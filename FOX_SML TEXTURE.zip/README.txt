FOX SML — Minecraft Java 1.21.11
A small, original 16x16 resource pack with simplified block textures.

Install:
1. Press Win + R.
2. Enter %appdata%\.minecraft\resourcepacks
3. Copy FOX_SML.zip into that folder.
4. Open Minecraft > Options > Resource Packs.
5. Move FOX SML to Selected and click Done.

Note: This pack changes a selection of block textures. All other textures stay vanilla.
A resource pack alone does not guarantee higher FPS; its main benefit is a simple visual style.
