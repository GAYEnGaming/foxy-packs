#version 120
#include "/lib/settings.glsl"
#include "/lib/sky.glsl"
uniform sampler2D colortex0;
uniform sampler2D depthtex0;
uniform float far;
uniform int isEyeInWater;
uniform ivec2 eyeBrightnessSmooth;
varying vec2 texCoord;

void main() {
    vec3 color = texture2D(colortex0, texCoord).rgb;
    float depth = texture2D(depthtex0, texCoord).r;
    vec4 vp = gbufferProjectionInverse * vec4(vec3(texCoord, depth) * 2.0 - 1.0, 1.0);
    vp.xyz /= vp.w;
    float dist = length(vp.xyz);
    vec3 dir = vp.xyz / max(dist, 0.0001);

    if (isEyeInWater == 0) {
        if (depth < 1.0) {
            float start = FOG_START - rainStrength * 0.30;
            float f = smoothstep(start, 1.0, dist / far);
            color = mix(color, skyAt(dir), f);
        }
    } else if (isEyeInWater == 1) {
        float d = depth < 1.0 ? dist : far;
        float bright = 0.25 + 0.75 * float(eyeBrightnessSmooth.y) / 240.0;
        float wf = 1.0 - exp(-d * 0.085);
        color *= vec3(0.55, 0.85, 1.0);
        color = mix(color, vec3(0.03, 0.20, 0.30) * bright, wf);
    } else {
        float d = depth < 1.0 ? dist : far;
        color = mix(color, vec3(0.85, 0.28, 0.04), 1.0 - exp(-d * 0.55));
    }
    gl_FragData[0] = vec4(color, 1.0);
}
