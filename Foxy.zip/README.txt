Foxy Shader - original lightweight shader pack (Iris / OptiFine, Minecraft Java 1.21.x)
Written from scratch; contains no code from other shader packs.
Install: put this .zip in .minecraft/shaderpacks, then Options > Video Settings > Shader Packs > Foxy.
Weak GPU? Shader Settings > Profile: LOW or POTATO.
