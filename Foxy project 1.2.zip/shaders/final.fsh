#version 120
#include "/lib/settings.glsl"
uniform sampler2D colortex0;
uniform float viewWidth;
uniform float viewHeight;
varying vec2 texCoord;

float luma(vec3 c) { return dot(c, vec3(0.299, 0.587, 0.114)); }

void main() {
    vec2 px = vec2(1.0 / viewWidth, 1.0 / viewHeight);
    vec3 c = texture2D(colortex0, texCoord).rgb;

#ifdef FXAA
    vec3 nw = texture2D(colortex0, texCoord + vec2(-1.0, -1.0) * px).rgb;
    vec3 ne = texture2D(colortex0, texCoord + vec2( 1.0, -1.0) * px).rgb;
    vec3 sw = texture2D(colortex0, texCoord + vec2(-1.0,  1.0) * px).rgb;
    vec3 se = texture2D(colortex0, texCoord + vec2( 1.0,  1.0) * px).rgb;
    float lNW = luma(nw), lNE = luma(ne), lSW = luma(sw), lSE = luma(se), lM = luma(c);
    float lMin = min(lM, min(min(lNW, lNE), min(lSW, lSE)));
    float lMax = max(lM, max(max(lNW, lNE), max(lSW, lSE)));
    if (lMax - lMin > max(0.04, lMax * 0.12)) {
        vec2 dir = vec2(-((lNW + lNE) - (lSW + lSE)), (lNW + lSW) - (lNE + lSE));
        float reduce = max((lNW + lNE + lSW + lSE) * 0.03125, 0.0078125);
        float inv = 1.0 / (min(abs(dir.x), abs(dir.y)) + reduce);
        dir = clamp(dir * inv, vec2(-6.0), vec2(6.0)) * px;
        vec3 a = 0.5 * (texture2D(colortex0, texCoord + dir * (1.0 / 3.0 - 0.5)).rgb
                      + texture2D(colortex0, texCoord + dir * (2.0 / 3.0 - 0.5)).rgb);
        vec3 b = a * 0.5 + 0.25 * (texture2D(colortex0, texCoord - dir * 0.5).rgb
                                  + texture2D(colortex0, texCoord + dir * 0.5).rgb);
        float lB = luma(b);
        c = (lB < lMin || lB > lMax) ? a : b;
    }
#endif

    if (SHARPEN > 0.0) {
        vec3 blur = 0.25 * (texture2D(colortex0, texCoord + vec2(px.x, 0.0)).rgb
                          + texture2D(colortex0, texCoord - vec2(px.x, 0.0)).rgb
                          + texture2D(colortex0, texCoord + vec2(0.0, px.y)).rgb
                          + texture2D(colortex0, texCoord - vec2(0.0, px.y)).rgb);
        c += (c - blur) * SHARPEN;
    }

#ifdef BLOOM
    {
        vec3 glow = vec3(0.0);
        float rad = viewHeight * 0.012;
        for (int i = 0; i < 12; i++) {
            float r = sqrt((float(i) + 0.5) / 12.0) * rad;
            float a = float(i) * 2.399963;
            vec3 s = texture2D(colortex0, texCoord + vec2(cos(a), sin(a)) * r * px).rgb;
            glow += max(s - 0.62, 0.0);
        }
        c += glow * (1.0 / 12.0) * BLOOM_STRENGTH * 3.0;
    }
#endif

    c = clamp(c, 0.0, 1.0);

    // vibrance + saturation
    float l = luma(c);
    float sat = max(c.r, max(c.g, c.b)) - min(c.r, min(c.g, c.b));
    c = mix(vec3(l), c, SATURATION + (1.0 - sat) * VIBRANCE);
    // gentle S-curve contrast
    c = clamp(c, 0.0, 1.0);
    c = mix(c, c * c * (3.0 - 2.0 * c), CONTRAST);
    // fox-warm grade
    c *= vec3(1.0 + WARMTH, 1.0 + WARMTH * 0.2, 1.0 - WARMTH);

    gl_FragData[0] = vec4(clamp(c, 0.0, 1.0), 1.0);
}
