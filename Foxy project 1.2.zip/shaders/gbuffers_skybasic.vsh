#version 120
varying vec4 glColor;
varying float starData;
void main() {
    glColor = gl_Color;
    starData = float(gl_Color.r == gl_Color.g && gl_Color.g == gl_Color.b && gl_Color.r > 0.0);
    gl_Position = ftransform();
}
