#version 120
uniform sampler2D texture;
varying vec2 texCoord;
varying vec4 glColor;
void main() {
    vec4 c = texture2D(texture, texCoord) * glColor;
    c.rgb *= 1.12;   // slightly brighter sun / moon
    gl_FragData[0] = c;
}
