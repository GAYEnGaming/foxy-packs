#version 120
#include "/lib/settings.glsl"
#include "/lib/distort.glsl"
varying vec2 texCoord;
varying vec4 glColor;
void main() {
    texCoord = gl_MultiTexCoord0.xy;
    glColor = gl_Color;
    vec4 p = ftransform();
    p.xy = shadowDistort(p.xy);
    p.z *= 0.2;
    gl_Position = p;
}
