#version 120
uniform sampler2D texture;
varying vec2 texCoord;
varying vec4 glColor;
void main() {
    vec4 c = texture2D(texture, texCoord) * glColor;
    if (c.a < 0.02) discard;
    gl_FragData[0] = c;
}
