#version 120
varying vec4 glColor;
void main() {
    gl_FragData[0] = glColor;
}
