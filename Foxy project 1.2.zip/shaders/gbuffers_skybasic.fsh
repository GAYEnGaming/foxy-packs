#version 120
#include "/lib/settings.glsl"
#include "/lib/sky.glsl"
varying vec4 glColor;
varying float starData;
void main() {
    vec3 col;
    float a = 1.0;
    if (starData > 0.5) {
        col = glColor.rgb * 1.2;      // stars
        a = glColor.a;
    } else if (glColor.a < 0.995) {
        col = glColor.rgb;            // sunrise / sunset fan keeps vanilla colours
        a = glColor.a;
    } else {
        vec2 uv = gl_FragCoord.xy / vec2(viewWidth, viewHeight);
        col = skyAt(viewDirFromScreen(uv, 1.0));
    }
    gl_FragData[0] = vec4(col, a);
}
