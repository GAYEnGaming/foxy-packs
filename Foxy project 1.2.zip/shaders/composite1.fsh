#version 120
#include "/lib/settings.glsl"
#include "/lib/sky.glsl"
uniform sampler2D colortex0;
uniform sampler2D depthtex0;
uniform mat4 gbufferProjection;
uniform int isEyeInWater;
varying vec2 texCoord;

// Screen-space sun shafts: radial march toward the sun, counting sky pixels.
void main() {
    vec3 color = texture2D(colortex0, texCoord).rgb;
#ifdef GODRAYS
    if (isEyeInWater == 0 && sunPosition.z < 0.0) {
        vec4 clip = gbufferProjection * vec4(sunPosition, 1.0);
        vec2 sUV = clip.xy / clip.w * 0.5 + 0.5;
        float noise = fract(52.9829189 * fract(dot(gl_FragCoord.xy, vec2(0.06711056, 0.00583715))));
        vec2 delta = (sUV - texCoord) * (0.85 / 14.0);
        vec2 uv = texCoord + delta * noise;
        float ray = 0.0;
        float w = 1.0;
        for (int i = 0; i < 14; i++) {
            uv += delta;
            if (uv.x > 0.0 && uv.x < 1.0 && uv.y > 0.0 && uv.y < 1.0) {
                ray += (texture2D(depthtex0, uv).r >= 0.99999 ? 1.0 : 0.0) * w;
            }
            w *= 0.93;
        }
        ray *= 0.07;
        float facing = max(dot(viewDirFromScreen(texCoord, 1.0), normalize(sunPosition)), 0.0);
        ray *= pow(facing, 3.0);
        vec3 tint = mix(vec3(1.0, 0.65, 0.35), vec3(1.0, 0.92, 0.75), foxyDay());
        color += tint * ray * GODRAYS_STRENGTH * foxyDay() * (1.0 - rainStrength);
    }
#endif
    gl_FragData[0] = vec4(color, 1.0);
}
