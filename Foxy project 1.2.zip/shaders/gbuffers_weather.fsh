#version 120
#include "/lib/settings.glsl"
#include "/lib/lighting.glsl"
uniform sampler2D texture;
varying vec2 texCoord;
varying vec2 lmCoord;
varying vec4 glColor;
varying vec3 viewPos;
varying vec3 normalV;
void main() {
    vec4 c = texture2D(texture, texCoord) * glColor;
    if (c.a < 0.02) discard;
    c.rgb *= foxyLight(lmCoord, viewPos, vec3(0.0, 1.0, 0.0), false);
    c.a *= 0.75;
    gl_FragData[0] = c;
}
