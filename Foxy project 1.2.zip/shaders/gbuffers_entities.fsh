#version 120
#include "/lib/settings.glsl"
#include "/lib/lighting.glsl"
uniform sampler2D texture;
uniform vec4 entityColor;
varying vec2 texCoord;
varying vec2 lmCoord;
varying vec4 glColor;
varying vec3 viewPos;
varying vec3 normalV;
void main() {
    vec4 c = texture2D(texture, texCoord) * glColor;
    if (c.a < 0.1) discard;
    c.rgb = mix(c.rgb, entityColor.rgb, entityColor.a);   // hurt flash
    c.rgb *= foxyLight(lmCoord, viewPos, normalize(normalV), true);
    gl_FragData[0] = c;
}
