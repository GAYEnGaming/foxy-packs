#version 120
varying vec4 glColor;
void main() {
    glColor = gl_Color;
    gl_Position = ftransform();
}
