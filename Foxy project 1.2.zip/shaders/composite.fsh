#version 120
#include "/lib/settings.glsl"
#include "/lib/sky.glsl"
uniform sampler2D colortex0;
uniform sampler2D depthtex0;
uniform float far;
uniform float near;
uniform int isEyeInWater;
uniform ivec2 eyeBrightnessSmooth;
varying vec2 texCoord;

#ifdef SSAO
float linearDepth(float d) {
    return (2.0 * near * far) / (far + near - (d * 2.0 - 1.0) * (far - near));
}
float ssao(vec2 uv, float depth) {
    float ld = linearDepth(depth);
    float noise = fract(52.9829189 * fract(dot(gl_FragCoord.xy, vec2(0.06711056, 0.00583715))));
    vec2 px = vec2(1.0 / viewWidth, 1.0 / viewHeight);
    float radius = clamp(90.0 / (ld + 6.0), 3.0, 22.0);
    float occ = 0.0;
    for (int i = 0; i < 8; i++) {
        float a = (float(i) + noise) * 0.7853982;
        float r = radius * (0.45 + 0.55 * fract(noise * 7.0 + float(i) * 0.37));
        vec2 o = vec2(cos(a), sin(a)) * r * px;
        float sd = linearDepth(texture2D(depthtex0, uv + o).r);
        float diff = ld - sd;
        occ += (diff > 0.08 && diff < 2.0) ? (1.0 - diff / 2.0) : 0.0;
    }
    return 1.0 - clamp(occ * 0.125 * SSAO_STRENGTH * 1.6, 0.0, 0.85);
}
#endif

void main() {
    vec3 color = texture2D(colortex0, texCoord).rgb;
    float depth = texture2D(depthtex0, texCoord).r;
    vec4 vp = gbufferProjectionInverse * vec4(vec3(texCoord, depth) * 2.0 - 1.0, 1.0);
    vp.xyz /= vp.w;
    float dist = length(vp.xyz);
    vec3 dir = vp.xyz / max(dist, 0.0001);

#ifdef SSAO
    if (depth < 1.0) color *= ssao(texCoord, depth);
#endif

    if (isEyeInWater == 0) {
        if (depth < 1.0) {
            float start = FOG_START - rainStrength * 0.30;
            float f = smoothstep(start, 1.0, dist / far);
            color = mix(color, skyAt(dir), f);
        }
    } else if (isEyeInWater == 1) {
        float d = depth < 1.0 ? dist : far;
        float bright = 0.25 + 0.75 * float(eyeBrightnessSmooth.y) / 240.0;
        float wf = 1.0 - exp(-d * 0.085);
        color *= vec3(0.55, 0.85, 1.0);
        color = mix(color, vec3(0.03, 0.20, 0.30) * bright, wf);
    } else {
        float d = depth < 1.0 ? dist : far;
        color = mix(color, vec3(0.85, 0.28, 0.04), 1.0 - exp(-d * 0.55));
    }
    gl_FragData[0] = vec4(color, 1.0);
}
