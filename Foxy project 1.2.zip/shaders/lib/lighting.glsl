#ifndef FOXY_LIGHTING
#define FOXY_LIGHTING
#include "/lib/uniforms.glsl"
#include "/lib/sky.glsl"
#include "/lib/distort.glsl"

uniform sampler2D lightmap;
uniform sampler2DShadow shadowtex1;
uniform mat4 shadowModelView;
uniform mat4 shadowProjection;
uniform vec3 shadowLightPosition;

float foxyShadow(vec3 viewPos, vec3 n, float ndl) {
#ifdef SHADOWS
    vec3 vp = viewPos + n * 0.08;
    vec3 feet = (gbufferModelViewInverse * vec4(vp, 1.0)).xyz;
    vec4 sp = shadowProjection * (shadowModelView * vec4(feet, 1.0));
    sp.xy = shadowDistort(sp.xy);
    sp.z *= 0.2;
    vec3 sc = sp.xyz * 0.5 + 0.5;
    sc.z -= 0.0007 + 0.0012 * (1.0 - clamp(ndl, 0.0, 1.0));
    if (sc.x < 0.0 || sc.x > 1.0 || sc.y < 0.0 || sc.y > 1.0 || sc.z > 1.0) return 1.0;
    float texel = SHADOW_SOFTNESS / float(shadowMapResolution);
    float s;
#if SHADOW_QUALITY == 1
    s = shadow2D(shadowtex1, sc).x;
#elif SHADOW_QUALITY == 3
    s = 0.0;
    for (int x = -1; x <= 1; x++) {
        for (int y = -1; y <= 1; y++) {
            s += shadow2D(shadowtex1, vec3(sc.xy + vec2(float(x), float(y)) * texel, sc.z)).x;
        }
    }
    s *= 0.1111111;
#else
    s  = shadow2D(shadowtex1, vec3(sc.xy + vec2(-0.5, -0.5) * texel, sc.z)).x;
    s += shadow2D(shadowtex1, vec3(sc.xy + vec2( 0.5, -0.5) * texel, sc.z)).x;
    s += shadow2D(shadowtex1, vec3(sc.xy + vec2(-0.5,  0.5) * texel, sc.z)).x;
    s += shadow2D(shadowtex1, vec3(sc.xy + vec2( 0.5,  0.5) * texel, sc.z)).x;
    s *= 0.25;
#endif
    float fade = smoothstep(shadowDistance * 0.72, shadowDistance * 0.97, length(feet.xz));
    return mix(s, 1.0, fade);
#else
    return 1.0;
#endif
}

// Returns an RGB light multiplier. Uses the vanilla lightmap so every
// dimension, night vision and gamma setting keeps working.
vec3 foxyLight(vec2 lm, vec3 viewPos, vec3 n, bool useShadow) {
    vec3 light = texture2D(lightmap, lm).rgb;

    float torch = pow(lm.x, 3.0) * (1.0 - lm.y * 0.6) * TORCH_WARMTH;
    light *= mix(vec3(1.0), vec3(1.14, 0.97, 0.78), clamp(torch, 0.0, 1.0));

    float day = foxyDay();
    float skyExp = smoothstep(0.45, 0.95, lm.y);
    float rain = 1.0 - rainStrength * 0.7;

    float lit = 1.0;
    if (useShadow) {
        vec3 L = normalize(shadowLightPosition);
        float ndl = dot(n, L);
        float facing = smoothstep(-0.05, 0.25, ndl);
        lit = foxyShadow(viewPos, n, ndl) * facing;
    }

    float strength = SHADOW_STRENGTH * mix(0.35, 1.0, day) * rain;
    float shade = (1.0 - lit) * skyExp * strength;
    light *= 1.0 - shade;
    light *= mix(vec3(1.0), vec3(0.88, 0.95, 1.08), clamp(shade * 1.5, 0.0, 1.0));
    light *= mix(vec3(1.0), vec3(1.06, 1.02, 0.94), lit * skyExp * day * rain);
    return light;
}
#endif
