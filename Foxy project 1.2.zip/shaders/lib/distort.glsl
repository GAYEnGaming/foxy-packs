// Shadow-map warp: more resolution near the player.
vec2 shadowDistort(vec2 p) {
    float f = length(p) * 0.85 + 0.15;
    return p / f;
}
