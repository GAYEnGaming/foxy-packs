#ifndef FOXY_SETTINGS
#define FOXY_SETTINGS

// ---------------- Shadows ----------------
#define SHADOWS
const int shadowMapResolution = 1024;      //[512 768 1024 1536 2048 3072]
const float shadowDistance = 64.0;         //[32.0 48.0 64.0 96.0 128.0 192.0]
const float sunPathRotation = -25.0;       //[-40.0 -30.0 -25.0 -20.0 -10.0 0.0 10.0 20.0 30.0 40.0]
#define SHADOW_QUALITY 1                   //[1 2 3]
#define SHADOW_SOFTNESS 1.5                //[1.0 1.5 2.0 3.0]
#define SHADOW_STRENGTH 0.50               //[0.25 0.35 0.50 0.60 0.70 0.80]

// ---------------- World ----------------
#define WAVING_FOLIAGE
#define WAVE_STRENGTH 1.0                  //[0.5 1.0 1.5 2.0]
#define WATER_WAVES
#define WATER_OPACITY 0.62                 //[0.40 0.50 0.62 0.72 0.82]
#define WATER_REFLECTIONS 0.75             //[0.0 0.25 0.50 0.75 1.0]
#define FOG_START 0.55                     //[0.30 0.40 0.55 0.70 0.85]
#define TORCH_WARMTH 1.0                   //[0.0 0.5 1.0 1.5]

// ---------------- High-end effects (off by default, enabled by HIGH / ULTRA profiles) ----------------
//#define SSAO
#define SSAO_STRENGTH 0.70                 //[0.30 0.50 0.70 0.90 1.00]
//#define GODRAYS
#define GODRAYS_STRENGTH 0.60              //[0.30 0.45 0.60 0.80 1.00]
//#define BLOOM
#define BLOOM_STRENGTH 0.30                //[0.15 0.30 0.45 0.60]

// ---------------- Post ----------------
#define FXAA
#define SHARPEN 0.25                       //[0.0 0.15 0.25 0.40 0.60]
#define SATURATION 1.08                    //[0.90 1.00 1.08 1.15 1.25]
#define VIBRANCE 0.20                      //[0.0 0.10 0.20 0.35]
#define CONTRAST 0.18                      //[0.0 0.10 0.18 0.30 0.40]
#define WARMTH 0.035                       //[-0.04 0.0 0.035 0.06 0.10]

#endif
