// Generic vertex stage for entities, hand, particles, etc.
#include "/lib/uniforms.glsl"
varying vec2 texCoord;
varying vec2 lmCoord;
varying vec4 glColor;
varying vec3 viewPos;
varying vec3 normalV;

void main() {
    texCoord = (gl_TextureMatrix[0] * gl_MultiTexCoord0).xy;
    lmCoord  = (gl_TextureMatrix[1] * gl_MultiTexCoord1).xy;
    glColor  = gl_Color;
    viewPos  = (gl_ModelViewMatrix * gl_Vertex).xyz;
    normalV  = normalize(gl_NormalMatrix * gl_Normal);
    gl_Position = gl_ProjectionMatrix * vec4(viewPos, 1.0);
}
