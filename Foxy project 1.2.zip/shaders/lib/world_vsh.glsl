// Terrain / water vertex stage with foliage + leaf waving.
#include "/lib/settings.glsl"
#include "/lib/uniforms.glsl"
attribute vec4 mc_Entity;
attribute vec2 mc_midTexCoord;
uniform vec3 cameraPosition;
uniform float frameTimeCounter;

varying vec2 texCoord;
varying vec2 lmCoord;
varying vec4 glColor;
varying vec3 viewPos;
varying vec3 normalV;
varying vec3 worldPos;
varying float blockId;

void main() {
    texCoord = (gl_TextureMatrix[0] * gl_MultiTexCoord0).xy;
    lmCoord  = (gl_TextureMatrix[1] * gl_MultiTexCoord1).xy;
    glColor  = gl_Color;
    normalV  = normalize(gl_NormalMatrix * gl_Normal);
    blockId  = mc_Entity.x;

    vec3 vp = (gl_ModelViewMatrix * gl_Vertex).xyz;
    vec3 feet = (gbufferModelViewInverse * vec4(vp, 1.0)).xyz;
    vec3 wp = feet + cameraPosition;

#ifdef WAVING_FOLIAGE
    float t = frameTimeCounter;
    if (blockId > 10000.5 && blockId < 10001.5) {
        // plants: only the top of the sprite sways
        float top = float(gl_MultiTexCoord0.t < mc_midTexCoord.t);
        float a = sin(t * 2.1 + wp.x * 0.9 + wp.z * 0.6) * 0.6
                + sin(t * 1.3 + wp.x * 0.5 - wp.z * 0.8) * 0.4;
        float b = cos(t * 1.7 + wp.z * 0.8 + wp.x * 0.4);
        feet.x += a * 0.065 * top * WAVE_STRENGTH;
        feet.z += b * 0.040 * top * WAVE_STRENGTH;
    } else if (blockId > 10001.5 && blockId < 10002.5) {
        // leaves: very gentle shimmer
        feet.x += sin(t * 1.4 + wp.x * 1.7 + wp.y * 1.1 + wp.z * 1.3) * 0.018 * WAVE_STRENGTH;
        feet.z += cos(t * 1.2 + wp.x * 1.1 + wp.y * 1.5 + wp.z * 1.9) * 0.018 * WAVE_STRENGTH;
        feet.y += sin(t * 1.6 + wp.x * 1.3 + wp.z * 1.7) * 0.010 * WAVE_STRENGTH;
    }
#endif

    worldPos = feet + cameraPosition;
    viewPos = (gbufferModelView * vec4(feet, 1.0)).xyz;
    gl_Position = gl_ProjectionMatrix * vec4(viewPos, 1.0);
}
