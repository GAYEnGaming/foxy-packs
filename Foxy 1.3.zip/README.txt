Foxy Shader - original shader pack (Iris / OptiFine, Minecraft Java 1.21.x)
Written from scratch; contains no code from other shader packs.
Install: put this .zip in .minecraft/shaderpacks, then Options > Video Settings > Shader Packs > Foxy.
Profiles: POTATO / LOW (weak GPUs) ... MEDIUM / HIGH / ULTRA (strong GPUs).
The End dimension has its own nebula sky and purple lighting (shaders/world1).
