#ifndef FOXY_ENDSKY
#define FOXY_ENDSKY
#include "/lib/uniforms.glsl"
// Procedural End sky: drifting purple nebula, stars and a glowing swirl core.
const vec3 END_CORE_DIR = vec3(0.38, 0.52, -0.77);   // roughly normalised, normalised again on use

float h31(vec3 p) {
    p = fract(p * 0.1031);
    p += dot(p, p.zyx + 31.32);
    return fract((p.x + p.y) * p.z);
}

float vnoise(vec3 p) {
    vec3 i = floor(p);
    vec3 f = fract(p);
    f = f * f * (3.0 - 2.0 * f);
    float a = mix(mix(h31(i),                 h31(i + vec3(1.0, 0.0, 0.0)), f.x),
                  mix(h31(i + vec3(0.0, 1.0, 0.0)), h31(i + vec3(1.0, 1.0, 0.0)), f.x), f.y);
    float b = mix(mix(h31(i + vec3(0.0, 0.0, 1.0)), h31(i + vec3(1.0, 0.0, 1.0)), f.x),
                  mix(h31(i + vec3(0.0, 1.0, 1.0)), h31(i + vec3(1.0, 1.0, 1.0)), f.x), f.y);
    return mix(a, b, f.z);
}

float fbm3(vec3 p, int oct) {
    float v = 0.0;
    float a = 0.5;
    for (int i = 0; i < 5; i++) {
        if (i >= oct) break;
        v += a * vnoise(p);
        p = p * 2.03 + 11.7;
        a *= 0.5;
    }
    return v;
}

// dirW: world-space unit view direction. oct: noise octaves (2 = cheap fog, 4 = full sky)
vec3 endSky(vec3 dirW, int oct) {
    float t = frameTimeCounter * 0.003;
    vec3 col = mix(vec3(0.012, 0.003, 0.030), vec3(0.060, 0.015, 0.100), 0.5 + 0.5 * dirW.y);

    // nebula clouds (domain-warped so they look wispy, not blobby)
    vec3 q = dirW * 2.4 + vec3(t, -t * 0.7, t * 0.5);
    float n1 = fbm3(q, oct);
    float n2 = fbm3(q * 1.8 + n1 * 1.6 + 7.3, oct);
    float neb = smoothstep(0.32, 0.82, n2);
    col += mix(vec3(0.28, 0.05, 0.42), vec3(0.70, 0.22, 0.88), n1) * neb * 0.80;
    col += vec3(0.05, 0.10, 0.42) * smoothstep(0.50, 0.90, fbm3(q * 0.7 + 19.0, oct)) * 0.55;

    // glowing core with spiral arms
    vec3 core = normalize(END_CORE_DIR);
    float d = dot(dirW, core);
    if (d > 0.0) {
        vec3 up = abs(core.y) < 0.99 ? vec3(0.0, 1.0, 0.0) : vec3(1.0, 0.0, 0.0);
        vec3 T = normalize(cross(up, core));
        vec3 B = cross(core, T);
        vec2 pp = vec2(dot(dirW, T), dot(dirW, B));
        float r = length(pp);
        float ang = atan(pp.y, pp.x);
        float arms = 0.5 + 0.5 * sin(ang * 5.0 - log(r + 0.01) * 8.0 + frameTimeCounter * 0.12);
        float halo = exp(-r * 16.0) * 0.55;
        float swirl = arms * exp(-r * 7.0) * smoothstep(0.0, 0.035, r) * 0.60;
        float disc = exp(-r * r * 4200.0) + exp(-r * 70.0) * 0.6;
        col += vec3(1.0, 0.60, 0.42) * swirl;
        col += vec3(0.95, 0.55, 0.85) * halo;
        col += vec3(1.0, 0.97, 0.92) * disc * 2.4;
    }

    // stars (more visible where the nebula is thin)
    vec3 sp = dirW * 85.0;
    vec3 id = floor(sp);
    float h = h31(id);
    float star = step(0.987, h) * smoothstep(0.42, 0.0, length(fract(sp) - 0.5));
    col += vec3(0.85, 0.80, 1.0) * star * (0.4 + 0.9 * h31(id + 3.1)) * (1.0 - neb * 0.7);
    return col;
}
#endif
