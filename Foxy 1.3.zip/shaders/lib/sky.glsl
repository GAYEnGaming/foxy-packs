#ifndef FOXY_SKY
#define FOXY_SKY
#include "/lib/uniforms.glsl"

float foxyDay() {
    return smoothstep(-0.08, 0.18, dot(normalize(sunPosition), normalize(upPosition)));
}

#ifdef FOXY_END
#include "/lib/endsky.glsl"
vec3 skyAt(vec3 dir) {
    return endSky(mat3(gbufferModelViewInverse) * dir, 2) * 0.85;
}
#else
// Sky gradient shared by the sky pass and distance fog so they match exactly.
vec3 skyAt(vec3 dir) {
    float up = dot(dir, normalize(upPosition));
    float h = smoothstep(0.0, 0.65, up);
    vec3 col = mix(fogColor, skyColor, sqrt(h));
    vec3 s = normalize(sunPosition);
    float d = max(dot(dir, s), 0.0);
    float glow = pow(d, 5.0) * 0.16 + pow(d, 48.0) * 0.30;
    col += vec3(1.0, 0.78, 0.52) * glow * foxyDay() * (1.0 - rainStrength * 0.8);
    return col;
}
#endif

vec3 viewDirFromScreen(vec2 uv, float depth) {
    vec4 p = gbufferProjectionInverse * vec4(vec3(uv, depth) * 2.0 - 1.0, 1.0);
    return normalize(p.xyz / p.w);
}
#endif
