#version 120
#include "/lib/settings.glsl"
#include "/lib/lighting.glsl"
uniform sampler2D texture;
varying vec2 texCoord;
varying vec2 lmCoord;
varying vec4 glColor;
varying vec3 viewPos;
varying vec3 normalV;
varying vec3 worldPos;
varying float blockId;

float waveH(vec2 p) {
    float t = frameTimeCounter;
    return sin(p.x * 1.7 + t * 1.3) * 0.5
         + sin(p.y * 2.1 - t * 1.1 + p.x * 0.4) * 0.5
         + sin((p.x + p.y) * 3.3 + t * 2.0) * 0.25;
}

void main() {
    vec4 tex = texture2D(texture, texCoord);
    vec4 c = tex * glColor;
    vec3 n = normalize(normalV);

    if (blockId > 10002.5 && blockId < 10003.5) {
        // ---- water ----
        vec2 p = mod(worldPos.xz, 512.0);
        vec3 nw = vec3(0.0, 1.0, 0.0);
#ifdef WATER_WAVES
        float e = 0.08;
        float h0 = waveH(p);
        float dx = waveH(p + vec2(e, 0.0)) - h0;
        float dz = waveH(p + vec2(0.0, e)) - h0;
        nw = normalize(vec3(-dx * 0.45, 1.0, -dz * 0.45));
#endif
        vec3 nv = normalize(mat3(gbufferModelView) * nw);
        vec3 V = normalize(-viewPos);
        float fres = 0.04 + 0.96 * pow(1.0 - max(dot(nv, V), 0.0), 5.0);
        float sky = smoothstep(0.3, 0.9, lmCoord.y);

        float lum = dot(tex.rgb, vec3(0.3333));
        vec3 base = glColor.rgb * vec3(0.72, 0.94, 1.0) * (0.65 + 0.7 * lum);
        base *= foxyLight(lmCoord, viewPos, n, true);

        vec3 refl = skyAt(reflect(-V, nv));
        base = mix(base, refl, clamp(fres * WATER_REFLECTIONS * sky, 0.0, 0.9));

        vec3 L = normalize(shadowLightPosition);
        vec3 H = normalize(L + V);
        float spec = pow(max(dot(nv, H), 0.0), 220.0);
        spec *= foxyDay() * (1.0 - rainStrength) * sky;
        base += vec3(1.0, 0.92, 0.75) * spec * 0.9;

        float alpha = mix(WATER_OPACITY, 0.95, fres * sky);
        gl_FragData[0] = vec4(base, max(alpha, spec));
    } else {
        // ---- glass, ice, slime ... ----
        c.rgb *= foxyLight(lmCoord, viewPos, n, true);
        gl_FragData[0] = c;
    }
}
