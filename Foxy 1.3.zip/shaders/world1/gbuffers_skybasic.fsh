#version 120
#define FOXY_END
#include "/lib/settings.glsl"
#include "/lib/sky.glsl"
void main() {
    vec2 uv = gl_FragCoord.xy / vec2(viewWidth, viewHeight);
    vec3 dirW = mat3(gbufferModelViewInverse) * viewDirFromScreen(uv, 1.0);
    gl_FragData[0] = vec4(endSky(dirW, 4), 1.0);
}
