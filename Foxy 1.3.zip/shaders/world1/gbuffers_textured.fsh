#version 120
#define FOXY_END
#include "/lib/settings.glsl"
#include "/lib/lighting.glsl"
uniform sampler2D texture;
varying vec2 texCoord;
varying vec2 lmCoord;
varying vec4 glColor;
varying vec3 viewPos;
varying vec3 normalV;
void main() {
    vec4 c = texture2D(texture, texCoord) * glColor;
    if (c.a < 0.02) discard;
    c.rgb *= foxyLight(lmCoord, viewPos, normalize(normalV), false);
    gl_FragData[0] = c;
}
