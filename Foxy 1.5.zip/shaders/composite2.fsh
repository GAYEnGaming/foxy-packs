#version 120
#include "/lib/settings.glsl"
#include "/lib/uniforms.glsl"
uniform sampler2D colortex0;
uniform sampler2D depthtex0;
uniform mat4 gbufferPreviousModelView;
uniform mat4 gbufferPreviousProjection;
uniform vec3 cameraPosition;
uniform vec3 previousCameraPosition;
varying vec2 texCoord;

// Camera motion blur: reproject each pixel into the previous frame and
// average along the screen-space motion vector. Strength is a multiplier.
void main() {
    vec3 color = texture2D(colortex0, texCoord).rgb;
#ifdef MOTION_BLUR
    float depth = texture2D(depthtex0, texCoord).r;
    if (depth > 0.56) {                      // skip the first-person hand
        vec4 view = gbufferProjectionInverse * vec4(vec3(texCoord, depth) * 2.0 - 1.0, 1.0);
        view /= view.w;
        vec4 world = gbufferModelViewInverse * view;
        world.xyz += cameraPosition - previousCameraPosition;
        vec4 prev = gbufferPreviousProjection * (gbufferPreviousModelView * world);
        vec2 prevUV = prev.xy / prev.w * 0.5 + 0.5;

        vec2 vel = (texCoord - prevUV) * 0.5 * MOTION_BLUR_STRENGTH;
        float len = length(vel);
        float maxLen = 0.07;
        if (len > maxLen) vel *= maxLen / len;

        if (len > 0.0004) {
            float noise = fract(52.9829189 * fract(dot(gl_FragCoord.xy, vec2(0.06711056, 0.00583715))));
            vec3 sum = color;
            float n = 1.0;
            for (int i = 1; i < 16; i++) {
                if (i >= MOTION_BLUR_SAMPLES) break;
                float t = (float(i) + noise) / float(MOTION_BLUR_SAMPLES) - 0.5;
                vec2 uv = clamp(texCoord + vel * t, vec2(0.001), vec2(0.999));
                if (texture2D(depthtex0, uv).r > 0.56) {   // never smear the hand over the world
                    sum += texture2D(colortex0, uv).rgb;
                    n += 1.0;
                }
            }
            color = sum / n;
        }
    }
#endif
    gl_FragData[0] = vec4(color, 1.0);
}
